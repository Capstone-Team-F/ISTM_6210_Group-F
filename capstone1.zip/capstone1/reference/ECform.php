<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Adding New Elective Course</title>
</head>
<body>

<?php
/*
Filename: add_course.php
Description: This file takes the data provided by a form and adds it to a table within a MySQL database
Author: Subhasish Dasgupta
Date: October 13, 2019
*/

//MySQL connection parameters. Remains the same for all connections to the database
$servername = "localhost";
$username = "root";
$password = "Sbb782mb7wls";

// Create connection
$conn = mysqli_connect($servername, $username, $password);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

//Select database
mysqli_select_db ( $conn , 'CapstoneDB' );

// SQL statement to insert form posted data into table:course and store statement in a variable $sql
// the variable parameters on the right are inside the $_POST are received from the form.
$sql = "INSERT INTO Course_Info set
course_crn = '$_POST[course_crn]',
faculty_id = '$_POST[faculty_id]'
course_credits '$_POST[course_credits]'";

// Insert SQL data in MySQL database table
mysqli_query($conn, $sql);

// Display confirmation
echo "A new elective course has been successfully added. <br>";

// Close connection
mysqli_close($conn);
?>
</span>

</body>
</html>
