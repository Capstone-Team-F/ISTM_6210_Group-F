<?php
/*
Name: Michael Wang
GWID: G39969285 */

$servername = "localhost";
$username = "root";
$password = "Sbb782mb7wls";
$database = "CapstoneDB";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
}
  echo "Connected successfully to Database <br> <br>";

  $search = $_POST["search"];
  //FORM
   $sql = "SELECT * FROM EC WHERE program='$search'";
   $result = mysqli_query($conn, $sql);
   if ($row = mysqli_fetch_array($result)){
     print_r ($row);
     echo "</br>";
   }

?>
