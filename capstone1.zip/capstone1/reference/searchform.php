<html lang=en>
<head>
    <title>Final Exam</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="form_content.css">
</head>
<body>
<h1> EC Database SEARCH FORM </h1>

<div class="container">
<form action="formconnect.php" method="post">
  <h2> Find by Program </h2>
    Search: <input type="text" name="search" placeholder="Enter Program (i.e. ISTM, FINA, etc)"</br>
  <input type="submit" value="Submit" />
</form>
</div>
</body>
<footer>
</footer>
</html>
