<?php
include 'db_multifilter.php';
$db_handle = new DBController();
$attributeResult = $db_handle->runQuery("SELECT DISTINCT course_attribute FROM Elective_Courses ORDER BY course_attribute ASC");
$termResult = $db_handle->runQuery("SELECT DISTINCT term FROM Elective_Courses ORDER BY term ASC");
?>
<html>
<head>
<link href="style_multifilter.css" type="text/css" rel="stylesheet" />
<title>Multiselect Dropdown Filter</title>
</head>

<body>
    <h2>Multiselect Dropdown Filter</h2>
    <form method="POST" name="search" action="index2.php">
        <div id="demo-grid">
            <div class="search-box">
                <select id="Attribute" name="course_attribute[]" multiple="multiple">
                    <option value="0" selected="selected">Select Course Attribute</option>
                        <?php
                        if (! empty($attributeResult)) {
                            foreach ($attributeResult as $key => $value) {
                                echo '<option value="' . $attributeResult[$key]['course_attribute'] . '">' . $attributeResult[$key]['course_attribute'] . '</option>';
                            }
                        }
                        ?>
                </select><br> <br>

                <select id="Attribute" name="course_attribute[]" multiple="multiple">
                  <option value="0" selected="selected">Select Term</option>
                  <?php
                  if (! empty($termResult)) {
                      foreach ($termResult as $key => $value) {
                          echo '<option value="' . $termResult[$key]['term'] . '">' . $termResult[$key]['term'] . '</option>';
                      }
                  }
                  ?>
                </select><br><br>
                </div>
                <button id="Filter">Search</button>
            </div>

                <?php
                  if (! empty($_POST['course_attribute'])) {
                ?>

            <table cellpadding="10" cellspacing="1">
              <thead>
                  <tr>
                        <th><strong>Course CRN</strong></th>
                        <th><strong>Course Title</strong></th>
                        <th><strong>Course Attribute</strong></th>
                        <th><strong>Credits</strong></th>
                        <th><strong>Program</strong></th>
                        <th><strong>Term</strong></th>
                  </tr>
              </thead>
                <tbody>
                <?php
                    $query = "SELECT * from Elective_Courses";
                    $i = 0;
                    $selectedOptionCount = count($_POST['course_attribute']);
                    $selectedOption = "";
                    while ($i < $selectedOptionCount) {
                        $selectedOption = $selectedOption . "'" . $_POST['course_attribute'][$i] . "'";
                        if ($i < $selectedOptionCount - 1) {
                            $selectedOption = $selectedOption . ", ";
                        }

                        $i ++;
                    }


                    $query = $query . " WHERE course_attribute in (" . $selectedOption .")";

                    $result = $db_handle->runQuery($query);

                }
                if (! empty($result)) {
                    foreach ($result as $key => $value) {
                        ?>
                <tr>
                        <td><div class="col" id="user_data_1"><?php echo $result[$key]['course_crn']; ?></div></td>
                        <td><div class="col" id="user_data_2"><?php echo $result[$key]['course_title']; ?> </div></td>
                        <td><div class="col" id="user_data_3"><?php echo $result[$key]['course_attribute']; ?> </div></td>
                        <td><div class="col" id="user_data_4"><?php echo $result[$key]['credits']; ?> </div></td>
                        <td><div class="col" id="user_data_5"><?php echo $result[$key]['program']; ?> </div></td>
                        <td><div class="col" id="user_data_6"><?php echo $result[$key]['term']; ?> </div></td>
                    </tr>
                <?php
                    }
                    ?>

                </tbody>
            </table>
            <?php
                }
                ?>
        </div>
    </form>
</body>
</html>
