<?php include_once 'config/db.php' ?>

<!DOCTYPE html>
<html>
<head>
  <title>Filtering MySQL</title>
  <link rel="stylesheet" type="text/css" href="bootstrap-4/css/bootstrap.css">
</head>

<body>
  <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <h3> MySQL Filtering </h3>
    </div>
  </nav>

  <div class="container">
    <h3> PHP Filters </h3>

      <div class="row">
        <form action="db.php" method="POST">
          <div>
            <label> Course CRN </label>
            <input type ="text" class="" name="course_crn" placeholder="Course CRN"></input>
          </div>

          <div>
            <label> Course Title </label>
            <input type ="text" class="" name="course_title" placeholder="Course Title"></input>
          </div>

          <div>
            <label> Course Attribute</label>
            <select name="course_attribute">
                <option>Select</option>
                <option value="ACCY">ACCY</option>
                <option value="CCAS">CCAS</option>
                <option value="IBUS">IBUS</option>
                <option value="ISTM">ISTM</option>
                <option value="FINA">FINA</option>
          </div>

          <div>
            <label> Specialized Master's Program </label>
            <select name="program">
              <option>Select</option>
              <option value="Master of Accountancy">Master of Accountancy</option>
              <option value="MS in Applied Finance">MS in Applied Finance</option>
              <option value="MS in Business Analytics">MS in Business Analytics</option>
              <option value="MS in Finance">MS in Finance</option>
              <option value="Master of Human Resource Management">Master of Human Resource Management</option>
              <option value="MS in Information Systems Technology">MS in Information Systems Technology</option>
              <option value="Master of Interdisciplinary Business Studies">Master of Interdisciplinary Business Studies</option>
              <option value="MS in International Business">MS in International Business</option>
              <option value="Master in Management">Master in Management</option>
              <option value="MS in Project Management">MS in Project Management</option>
              <option value="MS in Sport Management">MS in Sport Management</option>
              <option value="Master of Tourism Administration">Master of Tourism Administration</option>
          </div>

          <div>
            <label> Term </label>
              <input type="radio" name="term" value="Spring 2021">Spring 2021
              <input type="radio" name="term" value="Summer 2021">Summer 2021
              <input type="radio" name="term" value="Fall 2021">Fall 2021
          </div>

          <div>
            <input type="submit" name="submit" /><br>
          </div>

        </form>
      </div>
    </div>

    <div class="container">
      <div class="row">
        <table class="table table-striped table-hover">
          <thead>
            <tr>
                <th>Course CRN</th>
                <th>Course Title</th>
                <th>Course Attribute</th>
                <th>Credits</th>
                <th>Program</th>
                <th>Term</th>
            </tr>
          </thead>

          <tbody>
            <?php
              include("db.php");
              if(isset($_POST['submit'])){
                $course_crn = $_POST['course_crn'];
                $course_title = $_POST['course_title'];
                $course_attribute = $_POST['course_attribute'];
                $credits = $_POST['credits'];
                $program = $_POST['program'];
                $term = $_POST['term'];

                if($course_crn != "" || $course_title != "" || $course_attribute != "" || $credits != "" || $program != "" || $term != "") {
                  $query = "SELECT * FROM Elective_Courses WHERE course_crn = '$course_crn' OR course_title = '$course_title' OR credits = '$credits' OR program ='$program' OR term = '$term';";

                  $data = mysqli_query($conn, $query) or die('error');

                  if(mysqli_num_rows($data) > 0){
                    while($row = mysqli_fetch_assoc($data)){
                      $course_crn = $row['course_crn'];
                      $course_title = $row['course_title'];
                      $course_attribute = $row['course_attribute'];
                      $credits = $row['credits'];
                      $program = $row['program'];
                      $term = $row['term'];

                      ?>
                      <tr>
                        <td><div class="col" id="user_data_1"><?php echo $result[$key]['course_crn']; ?></div></td>
                        <td><div class="col" id="user_data_2"><?php echo $result[$key]['course_title']; ?> </div></td>
                        <td><div class="col" id="user_data_3"><?php echo $result[$key]['course_attribute']; ?> </div></td>
                        <td><div class="col" id="user_data_4"><?php echo $result[$key]['credits']; ?> </div></td>
                        <td><div class="col" id="user_data_5"><?php echo $result[$key]['program']; ?> </div></td>
                        <td><div class="col" id="user_data_6"><?php echo $result[$key]['term']; ?> </div></td>
                      </tr>
                      <?php
                    }

                  }
                  else{
                    ?>
                    <tr>
                      <td>Records Not Found</td>
                    </tr>
                    <?php
                  }
                }
              }
             ?>
          </tbody>

        </table>
      </div>
    </div>


</body>
</html>
