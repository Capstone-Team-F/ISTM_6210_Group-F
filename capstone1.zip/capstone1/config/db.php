<?php
$servername = "localhost";
$username = "root";
$password = "Sbb782mb7wls"
$dbname = "CapstoneDB";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection Failed! : " . mysqli_connect_error());
}

else {
  echo "Connection Established";
}
?>
