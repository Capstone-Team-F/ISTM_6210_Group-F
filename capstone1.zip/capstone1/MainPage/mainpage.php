<!DOCTYPE html>
<html lang="en" dir="ltr" xml:lang="en" prefix="og: http://ogp.me/ns# fb: http://www.facebook.com/2008/fbml content: http://purl.org/rss/1.0/modules/content/ dc: http://purl.org/dc/terms/ foaf: http://xmlns.com/foaf/0.1/ rdfs: http://www.w3.org/2000/01/rdf-schema# sioc: http://rdfs.org/sioc/ns# sioct: http://rdfs.org/sioc/types# skos: http://www.w3.org/2004/02/skos/core# xsd: http://www.w3.org/2001/XMLSchema# schema: http://schema.org/" class="js"><!--<![endif]--><head>
  <meta charset="utf-8"><link rel="shortcut icon" href="https://business.gwu.edu/sites/all/themes/gwu_marketing/favicon.ico" type="image/vnd.microsoft.icon">
<link rel="image_src" href="https://www.gwu.edu/sites/www.gwu.edu/files/image/gw-primary_90x90.jpg">
  <title>GWSB Electives Search Database  </title>

    <meta name="MobileOptimized" content="width">
    <meta name="HandheldFriendly" content="true">
    <meta name="viewport" content="width=device-width">
    <!--[if IEMobile]><meta http-equiv="cleartype" content="on"><![endif]-->

<!-- <style>
    table,tr,th,td {
      border-collapse: collapse;
      margin: 5px;
      font-size: 15px;
      max-width:800px;
      text-align: center;
      padding: 15px;
      border: 1px solid #B0C4DE;
      background: white;
      border-radius: 0px 0px 10px 10px;
    }

    tr{
  text-align: center;
}
    </style> -->

   <!--CSS from gw pages-->
   <link type="text/css" rel="stylesheet" href="https://business.gwu.edu/sites/g/files/zaxdzs1611/f/css/css_lQaZfjVpwP_oGNqdtWCSpJT1EMqXdMiU84ekLLxQnc4.css" media="all">
   <link type="text/css" rel="stylesheet" href="https://business.gwu.edu/sites/g/files/zaxdzs1611/f/css/css_uJq4i_pXk1UmtbCovdeCsAhlfvrAFcmFexwn2c_hQDQ.css" media="all">
   <link type="text/css" rel="stylesheet" href="https://business.gwu.edu/sites/g/files/zaxdzs1611/f/css/css_WEdRQKc3-rVPt3jpyk0PIsO7dQxCDkdIul4OxDe4OWY.css" media="all">
   <link type="text/css" rel="stylesheet" href="https://business.gwu.edu/sites/g/files/zaxdzs1611/f/css/css_AhMbyzK_9O_YAS88wHbaILEgRr-VgCrVDshFxCKtdKM.css" media="all">
   <link type="text/css" rel="stylesheet" href="https://business.gwu.edu/sites/g/files/zaxdzs1611/f/css/css_e2ks6L7AOdsUxi9VQiXOoPbtPJSpkrU1vtKyhE2pXR0.css" media="all">
     <link type="text/css" rel="stylesheet" href="https://business.gwu.edu/sites/g/files/zaxdzs1611/f/css/css_b4Us0-yqXsV3L_FpCNPxrZzpKtOze1EFJmsl_97aJE0.css" media="screen">

<body class="gw-today html not-front not-logged-in no-sidebars page-node page-node- page-node-555 node-type-general-content section-academics page-panels eu-cookie-compliance-processed" style=""><div id="sliding-popup" role="dialog" aria-describedby="popup-text" class="eu-cookie-withdraw-wrapper sliding-popup-bottom" style="bottom: 0px;">
</div>

  <a href="#main-content" class="element-invisible element-focusable skip-link">Skip to Content</a>


  <header class="header" id="header" role="banner">
      <div class="view view-main-header view-id-main_header view-display-id-main_header_panel_pane view-dom-id-48e18a18ef2a405fa7b09535b0576af3">

        <div class="view-content">
          <div class="views-row views-row-1 views-row-odd views-row-first views-row-last">

  <div class="utility-links" aria-hidden="false">
    <nav class="utility-links-menu" aria-label="utility links">

      <ul id="util-r" class="right-links">
  </li><li class="util-item util-item-right"><a href="../accounts/loginpage.php" target="">Faculty Member?</a></li></ul>
    </nav>
  </div>
  <div id="header-wrapper">
    <div class="gwlogo">
      <a href="https://business.gwu.edu" title="GW School of Business" target="_self"><div class="field field-name-field-logo field-type-image field-label-hidden"><div class="field-items"><div class="field-item even"><img typeof="foaf:Image" src="https://business.gwu.edu/sites/g/files/zaxdzs1611/f/image/SB_Header_215x90.jpg" width="215" height="90" alt="logo - The George Washington University School of Business"></div></div></div></a>
    </div>
      <div class="call-to-action">
      <a id="header-call-to-action" class="cap-button" href="https://business.gwu.edu/RFI" title="Request Info" target="_blank" aria-label="Request Info; link opens in new window">Request Info</a>  </div>
    </div>

    </div>
      </div>


  </div>
  </header>





<div id="nav-bar" aria-hidden="false" class="unsticky" style="position: static; z-index: 10;">
    <div id="nav-bar-wrapper">
        <div id="stickyLogo">
      <a href="https://business.gwu.edu" title="GW School of Business" target="_self"><img id="monogramLogo" src="https://business.gwu.edu/sites/g/files/zaxdzs1611/f/image/gw_mono_0.png" alt="logo - The George Washington University School of Business" title=""></a>
    </div>
        <div class="nav-group">
              <div id="smallBtn">
          <a id="nav-call-to-action" class="cap-button" href="https://business.gwu.edu/RFI" title="Request Info" target="_blank" aria-label="Request Info; link opens in new window">Request Info</a>
        </div>

        <!-- nav bar with gw links       -->
      <div id="navigation" role="navigation" class="responsive-menus-mean-menu-processed" style="display: block;">
          <nav id="main-nav" aria-label="main navigation">
            <ul class="nice-menu nice-menu-down nice-menu-menu-division-menu" id="nice-menu-2" role="menubar" aria-expanded="true"><li class="menu__item menu-744 menuparent  menu-path-node-5 first " role="menuitem" aria-haspopup="true"><a href="https://business.gwu.edu/about-gwsb" title="Learn About the GW School of Business (GWSB)" class="menu__link" tabindex="0">About</a><ul aria-expanded="false" role="menu" class="toplevelnav"><li class="menu__item menu-1357 menu-path-node-818 first " role="menuitem"><a href="https://business.gwu.edu/about-us/location" class="menu__link" tabindex="-1">Location</a></li>
                <li class="menu__item menu-1358 menu-path-node-819  " role="menuitem"><a href="https://business.gwu.edu/about-us/our-history" class="menu__link" tabindex="-1">History</a></li>
                <li class="menu__item menu-1354 menu-path-node-815  " role="menuitem"><a href="https://business.gwu.edu/mission" class="menu__link" tabindex="-1">Mission Statement</a></li>
                <li class="menu__item menu-2201 menu-path-node-1881  " role="menuitem"><a href="https://business.gwu.edu/welcome-message-dean-mehrotra" class="menu__link" tabindex="-1">Dean</a></li>
                <li class="menu__item menu-2276  menu-path-node-2856  " role="menuitem"><a href="https://business.gwu.edu/administration" class="menu__link" tabindex="-1">Administration</a></li>
                <li class="menu__item menu-1353  menu-path-node-813  last" role="menuitem"><a href="https://business.gwu.edu/about/alumni" class="menu__link" tabindex="-1">Alumni</a></li>
                </ul></li>

          <li class="menu__item menu-745 menuparent  menu-path-node-6 active-trail  " role="menuitem" aria-haspopup="true"><a href="https://business.gwu.edu/academics" title="Explore Our Departments, Discover Programs, Meet Our Faculty &amp; More" class="menu__link" tabindex="0">Academics</a><ul aria-expanded="false" role="menu" class="toplevelnav"><li class="menu__item menu-913  menu-path-node-177 active-trail first " role="menuitem"><a href="https://business.gwu.edu/academics/programs" class="menu__link" tabindex="-1">Programs</a></li>
          <li class="menu__item menu-912  menu-path-node-176  " role="menuitem"><a href="https://business.gwu.edu/academics/departments" class="menu__link" tabindex="-1">Departments</a></li>
          <li class="menu__item menu-1588 menu-path-node-814  last" role="menuitem"><a href="https://business.gwu.edu/academics/gwsb-course-syllabi" class="menu__link" tabindex="-1">Syllabi</a></li>
          </ul></li>
          <li class="menu__item menu-747 menuparent  menu-path-node-8  " role="menuitem" aria-haspopup="true"><a href="https://business.gwu.edu/admissions" title="View Information for Prospective Students About the Admissions Process and Degree Programs" class="menu__link" tabindex="0">Admissions</a><ul aria-expanded="false" role="menu" class="toplevelnav"><li class="menu__item menu-1447 menu-path-node-859 first " role="menuitem"><a href="https://business.gwu.edu/prospective-students/undergraduate-admissions" class="menu__link" tabindex="-1">Undergraduate Programs</a></li>
          <li class="menu__item menu-2661  menu-path-node-4806  last" role="menuitem"><a href="https://business.gwu.edu/graduate-admissions" class="menu__link" tabindex="-1">Graduate Programs</a></li>
          </ul></li>
          <li class="menu__item menu-2131 menuparent  menu-path-node-7  " role="menuitem" aria-haspopup="true"><a href="https://business.gwu.edu/student-resources" title="Discover Resources for Current Students, Including Academic Advising, Class Registration, Internships &amp; More" class="menu__link" tabindex="0">Student Resources</a><ul aria-expanded="false" role="menu" class="toplevelnav"><li class="menu__item menu-1400  menu-path-node-852 first " role="menuitem"><a href="https://business.gwu.edu/current-students/undergraduate" class="menu__link" tabindex="-1">Undergraduate Students</a></li>
          <li class="menu__item menu-1432  menu-path-node-855  " role="menuitem"><a href="https://business.gwu.edu/current-students/graduate" class="menu__link" tabindex="-1">Graduate Students</a></li>
          <li class="menu__item menu-1312  menu-path-node-765  " role="menuitem"><a href="https://business.gwu.edu/current-students/international" class="menu__link" tabindex="-1">International Students&nbsp;</a></li>
          <li class="menu__item menu-1760 menu-path-node-1441  last" role="menuitem"><a href="https://business.gwu.edu/commencement" class="menu__link" tabindex="-1">Commencement</a></li>
          </ul></li>
          <li class="menu__item menu-1455 menuparent  menu-path-node-11  " role="menuitem" aria-haspopup="true"><a href="https://business.gwu.edu/career-center" title="Find Mentorship Programs, Career Fairs, Interview Opportunities, Social Networks &amp; Other Resources" class="menu__link" tabindex="0">Career Center</a><ul aria-expanded="false" role="menu" class="toplevelnav"><li class="menu__item menu-2736 menu-path-node-5151 first " role="menuitem"><a href="https://business.gwu.edu/career-center/resources" class="menu__link" tabindex="-1">General Resources</a></li>
          <li class="menu__item menu-1590  menu-path-node-996  " role="menuitem"><a href="https://business.gwu.edu/career-center/undergraduate" class="menu__link" tabindex="-1">Undergraduate Career Resources</a></li>
          <li class="menu__item menu-1862  menu-path-node-1495  " role="menuitem"><a href="https://business.gwu.edu/career-center/graduate" class="menu__link" tabindex="-1">Graduate Career Resources</a></li>
          <li class="menu__item menu-1607  menu-path-node-1018  " role="menuitem"><a href="https://business.gwu.edu/career-center/alumni" class="menu__link" tabindex="-1">Alumni Career Resources</a></li>
          <li class="menu__item menu-2451  menu-path-node-3371  last" role="menuitem"><a href="https://business.gwu.edu/about-the-career-center" class="menu__link" tabindex="-1">About the Career Center</a></li>
          </ul></li>
          <li class="menu__item menu-751 menuparent  menu-path-node-13  " role="menuitem" aria-haspopup="true"><a href="https://business.gwu.edu/research" title="Explore Our Research Centers &amp; Institutes and View Faculty Research" class="menu__link" tabindex="0">Research</a><ul aria-expanded="false" role="menu" class="toplevelnav"><li class="menu__item menu-2221 menu-path-node-867 first " role="menuitem"><a href="https://business.gwu.edu/research/center-for-the-connected-consumer" class="menu__link" tabindex="-1">Center for the Connected Consumer</a></li>
          <li class="menu__item menu-2226  menu-path-node-868  " role="menuitem"><a href="https://business.gwu.edu/research/center-for-entrepreneurial-excellence-cfee" class="menu__link" tabindex="-1">Center for Entrepreneurial Excellence (CFEE)</a></li>
          <li class="menu__item menu-1477  menu-path-node-888  " role="menuitem"><a href="https://business.gwu.edu/research/ciber" class="menu__link" tabindex="-1">Center for International Business Education and Research (GW-CIBER)</a></li>
          <li class="menu__item menu-1733 menu-path-node-1314  " role="menuitem"><a href="https://business.gwu.edu/center-latin-american-issues-clai" class="menu__link" tabindex="-1">Center for Latin American Issues (CLAI)</a></li>
          <li class="menu__item menu-1518 menu-path-node-929  " role="menuitem"><a href="https://business.gwu.edu/research/center-for-real-estate-urban-analysis-creua" class="menu__link" tabindex="-1">Center for Real Estate &amp; Urban Analysis (CREUA)</a></li>
          <li class="menu__item menu-1519  menu-path-node-930  " role="menuitem"><a href="https://business.gwu.edu/research/european-union-research-center-eurc" class="menu__link" tabindex="-1">European Union Research Center (EURC)</a></li>
          <li class="menu__item menu-1527 menu-path-node-932  " role="menuitem"><a href="https://business.gwu.edu/research/european-union-research-center-eurc" class="menu__link" tabindex="-1">Global Financial Literacy Excellence Center (GFLEC)</a></li>
          <li class="menu__item menu-2231 menu-path-node-2631  " role="menuitem"><a href="https://business.gwu.edu/global-scope-lab" class="menu__link" tabindex="-1">The Global Scope Lab</a></li>
          <li class="menu__item menu-1577 menu-path-node-982  " role="menuitem"><a href="https://business.gwu.edu/research/the-growth-dialogue" class="menu__link" tabindex="-1">The Growth Dialogue</a></li>
          <li class="menu__item menu-2746 menu-path-node-5231  " role="menuitem"><a href="https://business.gwu.edu/gw-bridge" class="menu__link" tabindex="-1">GW-BRIDGE</a></li>
          <li class="menu__item menu-2181 menu-path-node-222  " role="menuitem"><a href="https://business.gwu.edu/investment" title="" class="menu__link" tabindex="-1">GW Investment Institute</a></li>
          <li class="menu__item menu-1578 menu-path-node-983  " role="menuitem"><a href="https://business.gwu.edu/research/institute-brazilian-issues" class="menu__link" tabindex="-1">Institute for Brazilian Issues</a></li>
          <li class="menu__item menu-1528  menu-path-node-933  " role="menuitem"><a href="https://business.gwu.edu/research/institute-corporate-responsibility" class="menu__link" tabindex="-1">Institute for Corporate Responsibility</a></li>
          <li class="menu__item menu-1545  menu-path-node-950  " role="menuitem"><a href="https://business.gwu.edu/research/institute-integrating-statistics-decision-sciences" class="menu__link" tabindex="-1">Institute for Integrating Statistics in Decision Sciences</a></li>
          <li class="menu__item menu-1864  menu-path-node-1507  " role="menuitem"><a href="https://business.gwu.edu/research/IITS" class="menu__link" tabindex="-1">International Institute of Tourism Studies</a></li>
          <li class="menu__item menu-1723 menu-path-node-1296  last" role="menuitem"><a href="https://business.gwu.edu/research/korean-management-institute" class="menu__link" tabindex="-1">Korean Management Institute (KMI)</a></li>
          </ul></li>
          <li class="menu__item menu-749 menuparent  menu-path-node-10  last" role="menuitem" aria-haspopup="true"><a href="https://business.gwu.edu/news-events" title="Read the Latest News at GWSB, Explore Upcoming Events &amp; More" class="menu__link" tabindex="0">News &amp; Events</a><ul aria-expanded="false" role="menu" class="toplevelnav"><li class="menu__item menu-1368  menu-path-node-829 first " role="menuitem"><a href="https://business.gwu.edu/news" class="menu__link" tabindex="-1">News &amp; Media</a></li>
          <li class="menu__item menu-1369  menu-path-node-830  " role="menuitem"><a href="https://business.gwu.edu/event-calendar" class="menu__link" tabindex="-1">Events</a></li>
          <li class="menu__item menu-2251 menu-path-node-2691  " role="menuitem"><a href="https://business.gwu.edu/george-talks-business" class="menu__link" tabindex="-1">The George Talks Business Series</a></li>
          <li class="menu__item menu-2696 menu-path-node-4961  " role="menuitem"><a href="https://business.gwu.edu/AY2020" class="menu__link" tabindex="-1">AY2020 Plan</a></li>
          <li class="menu__item menu-2556 menu-path-node-4486  last" role="menuitem"><a href="https://business.gwu.edu/AY2020" class="menu__link" tabindex="-1">Virtual Learning During COVID-19</a></li>
          </ul></li>
      </ul>
              </nav>
            </div>

</div>
</div>
        </div>


<div id="page" class="clearfix">
    <div id="main" class="clearfix">
        <div id="content" class="column" role="main">
                        <div class="gw-alert" id="gwalert">
                                    <div id="block-system-main" class="block block-system first last odd count-1 count-1"> </div>


<div class="panel-3col-stacked-limiter">
  <div class="panel-display panel-3col-stacked zen-clear">
        <div class="zen-clear"></div>
          <div class="panel-panel panel-col four-four">


<div class="panel-pane pane-node-content">
       <header class="major">
          <h1 class="pane-title">GWSB Elective Courses Offered</h1>
      </header>

      <div class="general-content-primary">
          <p>This is a database where all GWSB Masters students can search for possible elective courses to take in other departments.</p>
      </div>

<div class="searchcourses">
  <form method="post" action="../MainPage/mainpage.php">
    <input type="text" name="search" placeholder="Enter Course Title...">
    <!-- <select>
      <option value=""> Select Filter </option>
      <option value="course_title"> Course Title </option>
      <option value="course_attribute"> Course Attribute </option>
    </select> -->

    <input type="submit" value="SEARCH" />

<?php

$servername = "localhost";
$username = "root";
$password = "S02EnZ9OmkmW";
$database = "capstonedb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
if ($conn->connect_error) {
 die("Connection failed: " . $conn->connect_error);
}
/*echo "Connected successfully to Database <br> <br>";*/

$search = $_POST["search"];
//FORM
 $sql = "SELECT * FROM Course_Info WHERE course_title LIKE '%$search%'";
 $result = mysqli_query($conn, $sql);

 echo "<table >";
 echo "<thead>
       <tr>
             <th><strong>Course CRN</strong></th>
             <th><strong>Course Title</strong></th>
             <th><strong>Department</strong></th>
             <th><strong>Course Attribute</strong></th>
             <th><strong>Course Summary</strong></th>
             <th><strong>Credits</strong></th>
             <th><strong>Term</strong></th>
              <th><strong>Course Format</strong></th>
       </tr>
   </thead>";

 if($result) {
   while($row = mysqli_fetch_array($result)){
     echo "<tr>
     <td>" . $row['course_crn'] . "</td>
     <td>" . $row['course_title'] . "</td>
     <td>" . $row['department'] . "</td>
     <td>" . $row['course_attribute'] . "</td>
    <td>" . $row['course_summary'] . "</td>
     <td>" . $row['course_credits'] . "</td>
     <td>" . $row['term'] . "</td>
     <td>" . $row['course_format'] . "</td>
     </tr>";
   }
    echo "</table>";
}

?>

</form>
</div>



</div>


</div>
</div>
</div>

</div>
</div>
</div>
</div>

</body>


<!-- FOOTER BEGINS HERE FROM GW WEBSITE -->
<footer>

  <div id="local-footer" class="pane">


  <div class="panel-pane pane-views-panes pane-local-footer-gwtoday-footer-panel-pane" >
          <div class="view view-local-footer view-id-local_footer view-display-id-gwtoday_footer_panel_pane view-dom-id-9371c7feaad0765f63364c1db1cfb924">



        <div class="view-content">
          <div class="views-row views-row-1 views-row-odd views-row-first views-row-last">
      <div id="gwtoday-local-footer">
   <div id="gwtoday-footer">
   	 <div class="promotional-four-col">
       <div class="footer-logo" id ="promo-item-1">
         <div class="field field-name-field-gwtoday-logo field-type-text-long field-label-hidden"><div class="field-items"><div class="field-item even"><p><img alt="GW School of Business" src="../images/logo-footer.jpg" style="width: 225px; height: 69px;" /></p>

  <script type="text/javascript">
  piAId = '857403';
  piCId = '27570';
  piHostname = 'pi.pardot.com';

  (function() {
  	function async_load(){
  		var s = document.createElement('script'); s.type = 'text/javascript';
  		s.src = ('https:' == document.location.protocol ? 'https://pi' : 'http://cdn') + '.pardot.com/pd.js';
  		var c = document.getElementsByTagName('script')[0]; c.parentNode.insertBefore(s, c);
  	}
  	if(window.attachEvent) { window.attachEvent('onload', async_load); }
  	else { window.addEventListener('load', async_load, false); }
  })();
  </script></div></div></div>     </div>
       <div class="footer-address" id ="promo-item-2">
         <div class="field field-name-field-gwtoday-address field-type-text-long field-label-hidden"><div class="field-items"><div class="field-item even"><p><span class="marketing-text">Duqu&egrave;s Hall<br />
  2201 G Street NW<br />
  Washington, D.C. 20052</span></p>
  </div></div></div>     </div>
       <div class="footer-social-links" id ="promo-item-3">
         <div class="field field-name-field-gwtoday-social-links field-type-text-long field-label-hidden"><div class="field-items"><div class="field-item even"><p><span class="lightblue small-button"><a href="https://business.gwu.edu/RFI" target="_blank">Request Information</a></span></p>

  <p><span class="lightblue small-button"><a href="https://business.gwu.edu/gwsb-info-sessions" target="_blank">Attend an Info Session</a></span></p>

  <p><span class="lightblue small-button"><a href="https://gw.force.com/TX_SiteLogin" target="_blank">Apply Now</a></span></p>
  </div></div></div>     </div>
       <div class="footer-quick-links" id ="promo-item-4">
         <div class="field field-name-field-gwtoday-quick-links field-type-text-long field-label-hidden"><div class="field-items"><div class="field-item even"><p><a href="https://facebook.com/gwbusiness" target="_blank"><img alt="image - GW School of Business Facebook" src="../images/fb.png" style="padding: 5px; width: 35px; height: 35px;" /></a> <a href="https://www.linkedin.com/school/gwbusiness/" target="_blank"><img alt="image - GW School of Business LinkedIn" src="../images/linkedin.png" style="padding: 5px; width: 35px; height: 35px;" /></a> <a href="https://www.instagram.com/gwsbusiness/" target="_blank"><img alt="image - GW School of Business Instagram" src="../images/instagram.png" style="padding: 5px; width: 35px; height: 35px;" /></a> <a href="https://twitter.com/gwbusiness" target="_blank"><img alt="image - GW School of Business Twitter" src="../images/twitter.png" style="padding: 5px; width: 33px; height: 26px;" /></a> <a href="https://www.youtube.com/c/TheGeorgeWashingtonUniversitySchoolofBusiness" target="_blank"><img alt="image - GW School of Business YouTube" src="../images/youtube.png" style="padding: 5px; width: 35px; height: 35px;" /></a></p>
  </div></div></div>     </div>

  </div>
</div>
</div>
 </div>
   </div>
</div>
 </div>
 </div>
</div>
  </div>
   </div>
</div>

 <footer id="footer" class="region region-footer">
<div id="footer-wrapper">
   <div class="footer-logof">
       <a rel="home" href="http://www.gwu.edu?utm_medium=link&utm_campaign=editorial-footer&utm_source=gwu" target="_blank">
       <img class="gwlogo" typeof="foaf:Image" src="../images/gw.png" alt="The George Washington University, Washington, DC" height="42" width="300">
       </a>
       <a rel="external"  href="https://bicentennial.gwu.edu?utm_medium=link&utm_campaign=editorial-footer&utm_source=bicentennial" target="_blank">
       <img class="bicenlogo" typeof="foaf:Image" src="../images/2020logo.png" alt="GW's Bicentennial Celebration" height="42" width="300">
       </a>
   </div>
   <div class="row-one">
       <ul>
           <li>
               <a href="http://www.campusadvisories.gwu.edu?utm_medium=link&utm_campaign=editorial-footer&utm_source=campus-advisories" aria-label="View the latest Campus Advisories" target="_blank">Campus Advisories</a>
           </li>
           <li>
               <a href="https://go.gwu.edu/covid19?utm_medium=link&utm_campaign=editorial-footer&utm_source=coronavirus-response" target="_blank">Coronavirus Response</a>
           </li>
           <li>
               <a href="https://compliance.gwu.edu/equal-opportunity-nondiscrimination-anti-harassment-and-non-retaliation?utm_medium=link&utm_campaign=editorial-footer&utm_source=EEO-nondiscrimination-policy" target="_blank">EO/Nondiscrimination Policy</a>
           </li>
           <li>
               <a href="https://www.gwu.edu/privacy-notice?utm_medium=link&utm_campaign=editorial-footer&utm_source=privacy-notice" target="_blank">Privacy Notice</a>
           </li>
       </ul>
   </div>
   <div class="row-two">
       <ul>
           <li>
               <a href="https://www.gwu.edu/contact-gw?utm_medium=link&utm_campaign=editorial-footer&utm_source=contact-gw" aria-label="Contact GW with general questions or comments" target="_blank">Contact GW</a>
           </li>
           <li>
               <a href="https://accessibility.gwu.edu?utm_medium=link&utm_campaign=editorial-footer&utm_source=accessibility" aria-label="Visit GW's main accessibility website" target="_blank">Accessibility</a>
           </li>
           <li>
               <a href="https://www.gwu.edu/terms-use?utm_medium=link&utm_campaign=editorial-footer&utm_source=terms-use" target="_blank">Terms of Use</a>
           </li>
           <li>
               <a href="https://www.gwu.edu/copyright?utm_medium=link&utm_campaign=editorial-footer&utm_source=copyright" aria-label="Copyright information for GW websites" target="_blank">Copyright</a>
           </li>
           <li>
               <a href="https://www.gwu.edu/az-index?utm_medium=link&utm_campaign=editorial-footer&utm_source=az-index" target="_blank">A-Z Index</a>
           </li>
       </ul>
   </div>
   <div class="row-three">
       <ul>
           <li>GW is committed to digital accessibility. If you experience a barrier that affects your ability to access content on this page, let us know via the
               <a href="https://accessibility.gwu.edu/accessibility-feedback-form?utm_medium=link&utm_campaign=editorial-footer&utm_source=accessibility-feedback" target="_blank">Accessibility Feedback Form</a>.
           </li>
       </ul>
   </div>
</div>
 </footer>



</html>
