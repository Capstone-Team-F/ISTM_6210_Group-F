<!DOCTYPE html>
<html>
	<head lang="en">
	    <meta charset="utf-8">
	    <title>Adding New Elective Course</title>
			<link rel="stylesheet" href="../../style.css" />
			<link rel="stylesheet" href="../accounts.css" />
			<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"/>
			<style>
						body {
							background-image: url("../../images/kogan.jpeg");
							background-size: cover;
							background-repeat: no-repeat;
						}
			</style>
	</head>
	<ul>
	  <li><a a class="active" href="../../MainPage/mainpage.php">Home</a></li>

	  <li style="float:right"><a class="active" href="../loginpage.php">Log Out</a></li>
	</ul>

<body>

	<div class="header">
		<h2>Adding New Elective Course</h2>
	</div>

<div>
					<form  id="mainForm" action="CourseInfoform.php" method="POST" enctype="multipart/form-data" >
					<label>Please enter all new elective course information below </label>

					<div class="form-group">
					<label for="course_crn">Course CRN: </label>
						<input type="int" class="form-control" id="course_crn" name="course_crn">
					</div>

						<div class="form-group">
						<label for="faculty_id">Faculty ID:  </label>
						<input type="int" class="form-control" id="faculty_id" name="faculty_id">
						</div>

						<div class="form-group">
						<label for="course_title">Course Title: </label>
							<input type="int" class="form-control" id="course_title" name="course_title">
						</div>


						<div class="form-group">
						<label for="department">Department: </label>
						<select name="department" class="form-control">
							<option value="-- Select --"> -- Select -- </option>
								<option value="Accountancy">Accountancy</option>
								<option value="Decision">Decision Sciences</option>
								<option value="Finance">Finance</option>
								<option value="Information Systems and Technology Management">Information Systems and Technology Management</option>
								<option value="International Business">International Business</option>
								<option value="Managment">Management</option>
								<option value="Marketing">Marketing</option>
								<option value="Strategic Management and Public Policy">Strategic Management and Public Policy</option>
							</select>
							</div>

						<div class="form-group">
						<label for="course_attribute">Course Attribute: </label>
						<select name="course_attribute" class="form-control">
							<option value="-- Select --"> -- Select -- </option>
								<option value="ACCY">ACCY</option>
								<option value="DNSC">DNSC</option>
								<option value="FINA">FINA</option>
								<option value="ISTM">ISTM</option>
								<option value="IBUS">IBUS</option>
								<option value="MBAD">MBAD</option>
								<option value="MKTG">MKTG</option>
								<option value="SMPP">SMPP</option>
								</select>
							</div>

						</br>

						<input type="submit" name="submit" value="SUBMIT" class="btn btn-success">
						</form>

</div>

</body>
</html>

<?php
$connection = mysqli_connect("localhost","root","S02EnZ9OmkmW");
$db = mysqli_select_db($connection,'capstonedb');

if(isset($_POST['submit']))
{

// Escape user inputs for security
$course_crn = $_POST[`course_crn`];
$faculty_id = $_POST[`faculty_id`];
$course_title = $_POST[`course_title`];
$department = $_POST[`department`];
$course_attribute = $_POST[`course_attribute`];


// Attempt insert query execution
$query = "INSERT INTO `Course_Info` (`course_crn`, `faculty_id`, `course_title`, `department`, `course_attribute`) VALUES ('$_POST[course_crn]','$_POST[faculty_id]', '$_POST[course_title]','$_POST[department]','$_POST[course_attribute]') ";

$query_run = mysqli_query($connection,$query);

if($query_run)
{
 echo "Records added successfully.";
		 header( "refresh:2; url=../../MainPage/mainpage.php" );
}
else
{
			echo "ERROR: Could not able to execute $query. " . mysqli_error($connection);
}

}
?>
