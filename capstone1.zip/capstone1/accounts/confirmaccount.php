<?php

//MySQL connection parameters. Remains the same for all connections to the database
$servername = "localhost";
$username = "root";
$password = "S02EnZ9OmkmW"; // need to put your password here
$db = "capstonedb";


// Create connection
$conn = mysqli_connect($servername, $username, $password, $db);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

?>
