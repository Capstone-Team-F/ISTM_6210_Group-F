<!DOCTYPE html>
<html>
	<head lang="en">
	    <meta charset="utf-8">
	    <title>Adding New Faculty Member</title>
			<link rel="stylesheet" href="../../style.css" />
			<link rel="stylesheet" href="../accounts.css" />
			<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
			<style>
						body {
							background-image: url("../../images/kogan.jpeg");
							background-size: cover;
							background-repeat: no-repeat;
						}
			</style>
	</head>
	<ul>
		<li><a a class="active" href="../../MainPage/mainpage.php">Home</a></li>

		<li style="float:right"><a class="active" href="../loginpage.php">Log Out</a></li>
	</ul>

<body>

	<div class="header">
		<h2>Add New Faculty Member</h2>
	</div>

							<form id="mainForm" action="FacultyForm.php" method="POST" enctype="multipart/form-data" >
							<label>Please enter all new faculty member information below </label></br>

							<div class="form-group">
                <label>Faculty ID</label>
                <input type="number" name="faculty_id" class="form-control" placeholder="Enter Faculty ID">
              </div>


							<div class="form-group">
								<label for="facultyLVL">Faculty Level:  </label>
								<select name="facultyLVL" class="form-control">
									<option value="-- Select --"> -- Select -- </option>
										<option value="professor">Professor</option>
										<option value="program_director">Program Director</option>
										<option value="department_chair">Department Chair</option>
										</select>
							</div>

							<br>
								<input type="submit" name="submit" value="SUBMIT" class="btn btn-success">
							</form>

</body>
</html>

<?php
$connection = mysqli_connect("localhost","root","S02EnZ9OmkmW");
$db = mysqli_select_db($connection,'capstonedb');

if(isset($_POST['submit']))
{
	$faculty_id = $_POST[`faculty_id`];
	$facultyLVL = $_POST[`facultyLVL`];

	$query = "INSERT INTO `Faculty` (`faculty_id`, `facultyLVL`) VALUES ('$_POST[faculty_id]','$_POST[facultyLVL]')";

	if($query_run)
	{
	 echo "Faculty records successfully added.";
			 header( "refresh:2; url=../../DepartmentChair/departmentchair.php" );
	}
	else
	{
				echo "ERROR: Could not able to execute $query. " . mysqli_error($connection);
	}

}
?>
