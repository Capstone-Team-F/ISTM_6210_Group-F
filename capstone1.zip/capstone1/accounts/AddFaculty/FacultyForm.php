<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Adding New Faculty Member</title>
</head>
<body>

<?php
/*
Filename: add_course.php
Description: This file takes the data provided by a form and adds it to a table within a MySQL database
Author: Subhasish Dasgupta
Date: October 13, 2019
*/

//MySQL connection parameters. Remains the same for all connections to the database
session_start();

/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "S02EnZ9OmkmW","capstonedb");


// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

$faculty_id = mysqli_real_escape_string($link, $_REQUEST['faculty_id']);

$facultyLVL= mysqli_real_escape_string($link, $_REQUEST['facultyLVL']);

$sql = "INSERT INTO Faculty (faculty_id, facultyLVL) VALUES ('$faculty_id','$facultyLVL')";
// Display confirmation
if(mysqli_query($link, $sql)){
    echo "Faculty Records added successfully.";
    header( "refresh:2; url=../DepartmentChair/departmentchair.php" );
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

// Close connection
mysqli_close($link);

?>
