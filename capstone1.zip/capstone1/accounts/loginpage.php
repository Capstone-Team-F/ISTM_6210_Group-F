<?php

include("confirmaccount.php");

session_start();

$errors = array();

if (isset($_POST['login'])){
  $email = $_POST['email'];
  $password = $_POST['password'];

  //make sure form is filled out entirely
  if (empty($email)){
    array_push($errors, "Email Required");
  }
  if (empty($password)){
    array_push($errors, "Password Required");
  }

  $query = "SELECT * FROM Faculty WHERE email='$email' AND password='$password'";

  $result = mysqli_query($conn, $query);


  if(mysqli_num_rows($result)==1){
    echo "<script>alert('You are signed in')</script>";
    $facultyLVL = "SELECT facultyLVL from Faculty where email='$email' AND password='$password'";
    $facultyLVLs= mysqli_query($conn, $facultyLVL);

    $row = mysqli_fetch_array($facultyLVLs);

    if ($row['facultyLVL'] == "professor"){
      $_SESSION['professor'] = $email;
      header("Location: ../accounts/Professor/professor.php");
    }
    else if($row['facultyLVL'] == "program_director"){
      $_SESSION['program_director'] = $email;
      header("Location: ../accounts/ProgramDirector/program_director.php");
    }else if($row['facultyLVL'] == "department_chair"){
      $_SESSION['department_chair'] = $email;
      header("Location: ../accounts/DepartmentChair/departmentchair.php");
    }else{
    echo "<script>alert('Invalid Account Information')</script>";
  }

}
}

 ?>

<!DOCTYPE html>
<html>
<head>
    <title>Faculty Log In</title>
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="accounts.css" />
    <style>
    body {
      background-image: url("../images/gwbackground.png");
      background-size: cover;
      background-repeat: no-repeat;
    }
    </style>
</head>


<body>
  <div class="header">
    <h2>Log Into Faculty Account</h2>
  </div>

            <form method="POST">
        <?php include('errors.php'); ?>
                <div class="form-group">
                  <label>Email</label>
                  <input type="email" name="email" class="form-control" placeholder="Enter Email">
                </div>

              <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control">
              </div>
                <input type="submit" name="login" class="btn btn-info" value="Login">
                <br>
                <a href="createaccount.php">Don't have a faculty account? Create one here!</a>
            </form>


</body>
</html>
