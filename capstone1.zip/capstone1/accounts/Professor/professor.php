<?php
session_start();
 ?>

<!DOCTYPE html>
<html>
<head>
    <title>Professor Page</title>
    <link rel="stylesheet" href="../landingpage.css" />
    <link rel="stylesheet" href="../style.css" />
    <link rel="stylesheet" href="../../style.css" />
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
          body {
            background-image: url("../../images/cherry.jpeg");
            background-size: cover;
            background-repeat: no-repeat;
          }
    </style>
</head>

<ul>
  <li><a a class="active" href="professor.php">Home</a></li>
  <li><a style="color:white"><?php
    $professor = $_SESSION['professor'];
    $user = $professor;
    echo "Welcome $professor";
  ?></a></li>
  <li style="float:right"><a class="active" href="../loginpage.php">Log Out</a></li>
</ul>

<body>

<div class="container">

  <br>
  <button class="top_btn"> <a href="../CourseUpdate/CourseUpdate.php"> Update Exising Course </a> </button>
  <br>

</div>


<div class="container">
  <form method="post" action="../Professor/professor.php">
    <input type="text" id="searchbar" name="search" placeholder="Search By Course Title...">
    <!-- <select>
      <option value=""> Select Filter </option>
      <option value="course_title"> Course Title </option>
      <option value="course_attribute"> Course Attribute <
      /option>
    </select> -->

    <input type="submit" value="submit" />

<?php
$servername = "localhost";
$username = "root";
$password = "S02EnZ9OmkmW";
$database = "capstonedb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
if ($conn->connect_error) {
 die("Connection failed: " . $conn->connect_error);
}
/*echo "Connected successfully to Database <br> <br>";
*/

$search = $_POST["search"];
//FORM
 $sql = "SELECT * FROM Course_Info WHERE course_title LIKE '%$search%'";
 $result = mysqli_query($conn, $sql);


 echo "<table>";
 echo "<thead>
       <tr>
             <th><strong>Course CRN</strong></th>
             <th><strong>Course Title</strong></th>
             <th><strong>Course Attribute</strong></th>
             <th><strong>Credits</strong></th>
             <th><strong>Department</strong></th>
             <th><strong>Term</strong></th>
       </tr>
   </thead>";

 if($result) {
   while($row = mysqli_fetch_array($result)){
     echo "<tr>
     <td>" . $row['course_crn'] . "</td>
     <td>" . $row['course_title'] . "</td>
     <td>" . $row['course_attribute'] . "</td>
     <td>" . $row['course_credits'] . "</td>
     <td>" . $row['department'] . "</td>
     <td>" . $row['term'] . "</td>
     </tr>";

   }
}


?>

</form>
</div>

</body>
</html>
