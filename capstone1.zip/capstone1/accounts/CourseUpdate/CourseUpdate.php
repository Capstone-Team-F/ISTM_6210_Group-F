<!DOCTYPE html>
<html>
	<head>
	    <title>Update Elective Course Information</title>
			<link rel="stylesheet" href="../../style.css" />
			<link rel="stylesheet" href="../accounts.css" />
			<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"/>
			<style>
						body {
							background-image: url("../../images/kogan.jpeg");
							background-size: cover;
							background-repeat: no-repeat;
						}
			</style>
	</head>

	<ul>
	  <li><a class="active" href="../../MainPage/mainpage.php">Home</a></li>
	  <li style="float:right"><a class="active" href="../loginpage.php">Log Out</a></li>
	</ul>

<body>

	<div class="header">
		<h2>Update Elective Course Information</h2>
	</div>


<div>
<form  id="mainForm" action="CourseUpdate.php" method="POST" enctype="multipart/form-data" >
<label for="facultyid">Please enter all new course information below </label></br><br>
	<!--<div class="form-group">
 		<label for="faculty_id">Faculty ID:  </label>
 		<input type="int" id="faculty_id" name="faculty_id"></br></br><br>
 </div> -->

 <div class="form-group">
 		<label for="faculty_name">Faculty Name:  </label>
 		<input type="int" class="form-control" id="faculty_name" name="faculty_name">
 </div>

 <div class="form-group">
 		<label for="course_crn">Course CRN:  </label>
 		<input type="int" class="form-control" id="course_crn" name="course_crn">
 </div>

<div class="form-group">
		<label for="course_summary">Course Summary:  </label>
		<input type="varchar" class="form-control" id="course_summary" name="course_summary">
</div>

<div class="form-group">
		<label for="course_credits">Course Credits:  </label>
		<select name="course_credits" class="form-control">
			<option value="-- Select --"> -- Select -- </option>
				<option value="1"> 1 </option>
				<option value="2"> 2 </option>
				<option value="3"> 3 </option>
				</select>
</div>

<div class="form-group">
<label for="term">Course Term: </label>
<select name="term" class="form-control">
	<option value="-- Select --"> -- Select -- </option>
		<option value="Summer 2021">Summer 2021</option>
		<option value="Fall 2021">Fall 2021</option>
		<option value="Soring 2022">Spring 2022</option>
		</select>
	</div>

<div class="form-group">
		<label for="course_format">Course Format:  </label>
		<select name="course_format" class="form-control">
			<option value="-- Select --"> -- Select -- </option>
				<option value="In Person">In Person</option>
				<option value="Online">Online</option>
				<option value="Hybrid">Hybrid</option>
				</select>
</div>

		<br>

		<input type="submit" name="submit" value="SUBMIT" class="btn btn-success">
	</form>
</div>
</body>
</html>

<?php
$connection = mysqli_connect("localhost","root","S02EnZ9OmkmW");
$db = mysqli_select_db($connection,'capstonedb');

if(isset($_POST['submit']))
{
	$course_crn = $_POST[`course_crn`];

	$query = "UPDATE `Course_Info` SET
	`faculty_name`='$_POST[faculty_name]',
	`course_summary` ='$_POST[course_summary]',
	`course_credits` ='$_POST[course_credits]',
	`term`='$_POST[term]',
	`course_format` ='$_POST[course_format]'

	WHERE `course_crn`= '$_POST[course_crn]' ";

	$query_run = mysqli_query($connection,$query);

	if($query_run)
	{
	 echo "Records added successfully.";
		   header( "refresh:2; url=../../MainPage/mainpage.php" );
	}
	else
	{
		    echo "ERROR: Could not able to execute $query. " . mysqli_error($connection);
	}

}
?>
