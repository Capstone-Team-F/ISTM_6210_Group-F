<?php
session_start();

if (isset($_SESSION['professor'])){
  unset($_SESSION['professor']);
  header("Location: loginpage.php");
}

if (isset($_SESSION['program_director'])){
  unset($_SESSION['program_director']);
  header("Location: loginpage.php");
}

if (isset($_SESSION['department_chair'])){
  unset($_SESSION['department_chair']);
  header("Location: loginpage.php");
}
 ?>

<!--
session_start();

session_unset();
session_destroy();

header("Location: loginpage.php"); -->
