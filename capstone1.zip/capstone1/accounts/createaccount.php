<?php
$connection = mysqli_connect("localhost","root","S02EnZ9OmkmW");
$db = mysqli_select_db($connection,'capstonedb');


if(isset($_POST['signup']))
{
	$faculty_id = $_POST[`faculty_id`];
  $facultyLVL =$_POST[`facultyLVL`];

	$query = "UPDATE `Faculty` SET
	`fname`='$_POST[fname]',
	`lname` ='$_POST[lname]',
	`email` ='$_POST[email]',
	`password`='$_POST[password]'


	WHERE `faculty_id`= '$_POST[faculty_id]'AND `facultyLVL`= '$_POST[facultyLVL]' ";


	$query_run = mysqli_query($connection,$query);


  if ($query_run){
    echo "<script>alert('Account Created')</script>";
    header("Location:loginpage.php");

  }
  else{
    echo "<script>alert('Failed to create account')</script>";
  }

}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Faculty Sign Up</title>
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="accounts.css" />
    <style>
    body {
      background-image: url("../images/gwbackground.png");
      background-size: cover;
      background-repeat: no-repeat;
    }
    </style>
</head>

<body>
  <div class="header">
    <h2>Create Faculty Account</h2>
  </div>


            <form method="POST">
              <div class="form-group">
                <label>Faculty ID</label>
                <input type="number" name="faculty_id" class="form-control" placeholder="Enter Faculty ID">
              </div>

                <div class="form-group">
                  <label>First Name</label>
                  <input type="text" name="fname" class="form-control" placeholder="Enter First Name">
                </div>

                <div class="form-group">
                  <label>Last Name</label>
                  <input type="text" name="lname" class="form-control" placeholder="Enter Last Name">
                </div>

                <div class="form-group">
                  <label>Email</label>
                  <input type="email" name="email" class="form-control" placeholder="Enter Email">
                </div>

              <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control">
              </div>

              <div class="form-group">
                <label>Select Your Faculty Level</label>
                <select name="facultyLVL" class="form-control">
                    <option value="">Faculty Level</option>
                    <option value="professor">Professor</option>
                    <option value="program_director">Program Director</option>
                    <option value="department_chair">Department Chair</option>
                  </div>
                  <br> <br> <br>
                <input type="submit" name="signup" class="btn btn-info">
                <br>
                <a href="loginpage.php">Already have a faculty account? Log in here!</a>
            </form>



</body>
</html>
