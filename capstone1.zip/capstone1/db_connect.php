<?php
/*
Name: Michael Wang
GWID: G39969285 */
echo "<style>
            table,tr,th,td
            {
                border: 1px solid black;
            }
        </style>";

$servername = "localhost";
$username = "root";
$password = "Sbb782mb7wls";
$database = "capstonedb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
}
  echo "Connected successfully to Database <br> <br>";

  $search = $_POST["search"];
  //FORM
   $sql = "SELECT * FROM Course_Info WHERE course_title LIKE '%$search%'";
   $result = mysqli_query($conn, $sql);

   echo "<table >";
   echo "<thead>
         <tr>.
               <th><strong>Course CRN</strong></th>
               <th><strong>Course Title</strong></th>
               <th><strong>Course Attribute</strong></th>
               <th><strong>Credits</strong></th>
               <th><strong>Department</strong></th>
               <th><strong>Term</strong></th>
         </tr>
     </thead>";

   if($result) {
     while($row = mysqli_fetch_array($result)){
       echo "<tr>
       <td>" . $row['course_crn'] . "</td>
       <td>" . $row['course_title'] . "</td>
       <td>" . $row['course_attribute'] . "</td>
       <td>" . $row['course_credits'] . "</td>
       <td>" . $row['department'] . "</td>
       <td>" . $row['term'] . "</td>
       </tr>";

     }
  }

  /* echo "<table>"; // start a table tag in the HTML
if($row = mysql_fetch_array($result)){   //Creates a loop to loop through results
      echo "<tr>
      <td>" . $row['course_crn'] . "</td>
      <td>" . $row['course_title'] . "</td>
      <td>" . $row['course_attribute'] . "</td>
      <td>" . $row['credits'] . "</td>
      <td>" . $row['program'] . "</td>
      <td>" . $row['term'] . "</td>
      </tr>";  //$row['index'] the index here is a field name
    }

    echo "</table>"; //Close the table in HTML
*/

?>
