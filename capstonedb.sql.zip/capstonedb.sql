-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 29, 2021 at 06:12 AM
-- Server version: 8.0.21
-- PHP Version: 7.3.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `capstonedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `Course_Info`
--

CREATE TABLE `Course_Info` (
  `course_crn` int NOT NULL,
  `faculty_id` int NOT NULL,
  `faculty_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `course_title` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `course_attribute` varchar(100) NOT NULL,
  `course_summary` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `course_credits` int DEFAULT NULL,
  `department` varchar(100) NOT NULL,
  `term` varchar(100) NOT NULL,
  `course_format` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Course_Info`
--

INSERT INTO `Course_Info` (`course_crn`, `faculty_id`, `faculty_name`, `course_title`, `course_attribute`, `course_summary`, `course_credits`, `department`, `term`, `course_format`) VALUES
(111111, 111111, 'Jacob', 'Intro to Python', 'ISTM 3119', 'http://bulletin.gwu.edu/search/?P=ISTM+3119', 3, 'Information Systems and Technology Management', 'Fall 2021', 'Online'),
(222222, 222222, 'Michael', 'Internet of Thing Management', 'ISTM 6217', 'http://bulletin.gwu.edu/search/?P=ISTM+6217', 3, 'Information Systems and Technology Management', 'Fall 2021', 'Hybrid'),
(333333, 333333, 'Julissa', 'Introduction to Managerial Accounting', 'ACCY 2002', 'http://bulletin.gwu.edu/search/?P=ACCY+2002', 3, 'Accountancy', 'Spring 2021', 'Online'),
(444444, 444444, 'Carlos', 'Consumer Behavior', 'MKTG 3142', 'http://bulletin.gwu.edu/search/?P=MKTG+3142', 3, 'Marketing', 'Spring 2021', 'Online'),
(555555, 555555, 'Ayobami', 'Introduction to International Business', 'IBUS 3001', 'http://bulletin.gwu.edu/search/?P=ibus+3001', 3, 'International Business', 'Spring 2022', 'In Person'),
 (666666, 111111, 'Jacob', 'Relational Databases', 'ISTM 6202', 'http://bulletin.gwu.edu/search/?P=ISTM+6202', 3, 'Information Systems and Technology Management', 'Fall 2021', 'Hybrid'),
(777777, 222222, 'Michael', 'Web App Development', 'ISTM 6205', 'http://bulletin.gwu.edu/search/?P=ISTM+6205', 3, 'Information Systems and Technology Management', 'Fall 2021', 'Hybrid'),
(888888, 333333, 'Julissa', 'Nonprofit Accounting', 'ACCY 6705', 'http://bulletin.gwu.edu/search/?P=ACCY+6705', 3, 'Accountancy', 'Fall 2021', 'In Person'),
(999999, 444444, 'Carlos', 'Digital Marketing Analytics', 'MKTG 6262', 'http://bulletin.gwu.edu/search/?P=MKTG+6262', 3, 'Marketing', 'Fall 2021', 'Online'),
(112233, 555555, 'Ayobami', 'Intl Business Strategy', 'IBUS 6401', 'http://bulletin.gwu.edu/search/?P=ibus+6401', 3, 'International Business', 'Spring 2022', 'In Person');


-- --------------------------------------------------------

--
-- Table structure for table `Faculty`
--

CREATE TABLE `Faculty` (
  `faculty_id` int NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `facultyLVL` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Faculty`
--

INSERT INTO `Faculty` (`faculty_id`, `fname`, `lname`, `email`, `password`, `facultyLVL`) VALUES
(111111, 'Jacob', 'Quiles', 'jquiles@gwu.edu', '1', 'professor'),
(222222, 'Michael', 'Wang', 'mwang@gwu.edu', '2', 'program_director'),
(333333, 'Julissa', 'Toledo', 'jtoldeo@gwu.edu', '3', 'department_chair'),
(444444, 'Carlos', 'Machado', 'cmachado@gwu.edu', '4', 'professor'),
(555555, 'Ayobami', 'Olatunji', 'aolatunji@gwu.edu', '5', 'program_director');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Course_Info`
--
ALTER TABLE `Course_Info`
  ADD PRIMARY KEY (`course_crn`),
  ADD KEY `faculty_id` (`faculty_id`);

--
-- Indexes for table `Faculty`
--
ALTER TABLE `Faculty`
  ADD PRIMARY KEY (`faculty_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Course_Info`
--
ALTER TABLE `Course_Info`
  ADD CONSTRAINT `Course_Info_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `Faculty` (`faculty_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
